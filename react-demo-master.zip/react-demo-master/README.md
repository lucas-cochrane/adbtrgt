# react-demo
Hypothetical online e-commerce site implemented in React

Live demo: http://developers.adobetarget.com/react-demo/public/#/